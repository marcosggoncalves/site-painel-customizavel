<?php

return [
	'fileNotFound' => 'Arquivo não encontrado: {0}',
	'cannotMove'   => 'Não pode mover o arquivo {0} para {1} ({2})',
];
