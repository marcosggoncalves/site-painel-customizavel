<?php

return [
	'invalidParameter'    => 'Um parâmetro não corresponde ao tipo esperado.',
	'missingDefaultRoute' => 'Não é possível determinar o que deve ser exibido. Uma rota padrão não foi especificada no arquivo de roteamento.',
];
