<?php

return [
	'languageGetLineInvalidArgumentException' => 'A linha obtida deve ser uma string ou um array de strings.'
];
