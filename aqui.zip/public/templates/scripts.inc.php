<script src="adminLTE/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="adminLTE/bootstrap/js/bootstrap.min.js"></script>
<script src="adminLTE/dist/js/app.min.js"></script>